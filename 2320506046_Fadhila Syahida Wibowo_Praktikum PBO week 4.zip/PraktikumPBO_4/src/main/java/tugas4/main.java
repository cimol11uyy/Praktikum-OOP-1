/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas4;

/**
 *
 * @author ASUS
 */
public class main {
    public static void main(String[] args) {
        pekerja Dhila = new pekerja("Dhila", 20, "Programmer", 5000000);
        
        Dhila.setnama("Fasya");
        
        Dhila.tostring();
   }
}
