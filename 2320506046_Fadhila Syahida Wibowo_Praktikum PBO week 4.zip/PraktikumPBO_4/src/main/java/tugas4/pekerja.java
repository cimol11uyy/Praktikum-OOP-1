/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas4;

/**
 *
 * @author ASUS
 */
public class pekerja extends manusia {
    private int gaji;
    
    public pekerja(String nama, int usia, String pekerjaan, int gaji){
        super(nama, usia, pekerjaan);
        this.nama=nama;
        this.usia=usia;
        this.pekerjaan=pekerjaan;
        this.gaji=gaji;
    }
    
    public int getgaji(){
        return gaji;
    }
    public void setgaji(int gaji){
        this.gaji=gaji;
    }
    
    public void tostring(){
        System.out.println("nama: "+getnama());
        System.out.println("usia: "+usia);
        System.out.println("pekerjaan: "+pekerjaan);
        System.out.println("gaji: "+gaji);
    }  
}
