/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_4;
import praktikum4.kendaraan;
/**
 *
 * @author ASUS
 */
public class PraktikumPBO_4 {

    public static void main(String[] args) {
        kendaraan mobil = new kendaraan("toyota", "avanza", 2020);
        
        System.out.println("merk: "+mobil.getmerk());
        System.out.println("model: "+mobil.getmodel());
        System.out.println("tahun: "+mobil.gettahun());
        
        mobil.setmodel("innova");
        mobil.settahun(2021);
        
        System.out.println("model baru: "+mobil.getmodel());
        System.out.println("tahun baru: "+mobil.gettahun());
    }
}
