/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author ASUS
 */
public class mobil extends kendaraan{
    private int jumlahpintu;
    
    public mobil(String merk, String model, int tahun, int jumlahpintu){
        super(merk, model, tahun);
        this.jumlahpintu = jumlahpintu;
    }
    
    
    public void tampilkaninfomobil(){
        System.out.println("tahun: "+tahun);
        System.out.println("jumlah pintu: "+jumlahpintu);
    }
}
