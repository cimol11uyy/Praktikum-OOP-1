/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author ASUS
 */
public class kendaraan {
    private String merk;
    public String model;
    protected int tahun;
    
    public kendaraan(String merk, String model, int tahun){
        this.merk=merk;
        this.model=model;
        this.tahun=tahun;
    }
    public String getmerk(){
        return merk;
    }
    public void setmerk(String merk){
        this.merk=merk;
    }
    public String getmodel(){
        return model;
    }
    public void setmodel(String model){
        this.model=model;
    }
    public int gettahun(){
        return tahun;
    }
    public void settahun(int tahun){
        this.tahun=tahun;
    }
    
    public void tampilkaninfokendaraan(){
        System.out.println("merk: "+merk);
        System.out.println("model: "+model);
        System.out.println("tahun: "+tahun);
    }
}


