/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal;
import java.io.*;
/**
 *
 * @author ASUS
 */
public class simpanSer {
    public static void main(String[] args) {
        String filePath = "buku.ser";
        
        Buku buku = new Buku("Desain grafis", "Tere", 2011);
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(buku);
            System.out.println("Objek buku berhasil disimpan ke file: " + filePath);
        } 
        catch (IOException e) {
            System.out.println("Terjadi kesalahan saat menyimpan objek.");
            e.printStackTrace();
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            Buku deserializedBuku = (Buku) ois.readObject();
            System.out.println("\nObjek buku berhasil dibaca dari file:");
            deserializedBuku.tampilkaninfo();
        } 
        catch (IOException | ClassNotFoundException e) {
            System.out.println("Terjadi kesalahan saat membaca objek.");
            e.printStackTrace();
        }
    }
}
